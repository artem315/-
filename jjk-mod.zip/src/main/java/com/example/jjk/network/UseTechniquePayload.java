package com.example.jjk.network;

import com.example.jjk.JjkMod;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/** C2S: игрок нажал клавишу техники. slot: 0, 1 — техники персонажа, 2 — обратная проклятая техника. */
public record UseTechniquePayload(int slot) implements CustomPacketPayload {
    public static final CustomPacketPayload.Type<UseTechniquePayload> TYPE =
            new CustomPacketPayload.Type<>(JjkMod.id("use_technique"));

    public static final StreamCodec<RegistryFriendlyByteBuf, UseTechniquePayload> CODEC =
            StreamCodec.composite(
                    ByteBufCodecs.VAR_INT, UseTechniquePayload::slot,
                    UseTechniquePayload::new);

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
