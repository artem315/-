package com.example.jjk.data;

import com.example.jjk.JjkMod;
import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentSyncPredicate;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;

public final class ModAttachments {
    /**
     * Данные игрока: сохраняются на диск, переживают смерть,
     * синхронизируются только с самим игроком (для HUD).
     */
    public static final AttachmentType<PlayerJjkData> PLAYER_DATA = AttachmentRegistry.create(
            JjkMod.id("player_data"),
            builder -> builder
                    .persistent(PlayerJjkData.CODEC)
                    .copyOnDeath()
                    .syncWith(PlayerJjkData.STREAM_CODEC, AttachmentSyncPredicate.targetOnly()));

    private ModAttachments() {
    }

    /** Вызов гарантирует загрузку класса и регистрацию вложения. */
    public static void init() {
    }
}
