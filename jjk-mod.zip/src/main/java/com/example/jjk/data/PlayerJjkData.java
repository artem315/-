package com.example.jjk.data;

import com.example.jjk.character.JjkCharacter;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;

public record PlayerJjkData(JjkCharacter character, int cursedEnergy, int maxCursedEnergy) {
    /** Сохранение на диск. */
    public static final Codec<PlayerJjkData> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            JjkCharacter.CODEC.fieldOf("character").forGetter(PlayerJjkData::character),
            Codec.INT.fieldOf("cursed_energy").forGetter(PlayerJjkData::cursedEnergy),
            Codec.INT.fieldOf("max_cursed_energy").forGetter(PlayerJjkData::maxCursedEnergy)
    ).apply(instance, PlayerJjkData::new));

    /** Синхронизация сервер -> клиент (для HUD). */
    public static final StreamCodec<RegistryFriendlyByteBuf, PlayerJjkData> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.VAR_INT.map(i -> JjkCharacter.values()[i], JjkCharacter::ordinal), PlayerJjkData::character,
            ByteBufCodecs.VAR_INT, PlayerJjkData::cursedEnergy,
            ByteBufCodecs.VAR_INT, PlayerJjkData::maxCursedEnergy,
            PlayerJjkData::new);

    public static PlayerJjkData initial(JjkCharacter character) {
        int base = character.baseCursedEnergy();
        return new PlayerJjkData(character, base, base);
    }

    public PlayerJjkData withCursedEnergy(int value) {
        return new PlayerJjkData(character, Math.max(0, Math.min(value, maxCursedEnergy)), maxCursedEnergy);
    }
}
