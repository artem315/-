package com.example.jjk.server;

import com.example.jjk.data.JjkData;
import com.example.jjk.network.ModNetworking;
import com.example.jjk.technique.TechniqueExecutor;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.server.level.ServerPlayer;

public final class ServerEvents {
    private ServerEvents() {
    }

    public static void register() {
        // Первый вход: нет персонажа — просим клиента открыть меню.
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            ServerPlayer player = handler.getPlayer();
            if (!JjkData.hasCharacter(player)) {
                ModNetworking.requestSelection(player);
            }
        });

        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) ->
                TechniqueExecutor.clearCooldowns(handler.getPlayer().getUUID()));

        // Регенерация проклятой энергии раз в секунду.
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (server.getTickCount() % 20 != 0) {
                return;
            }
            for (ServerPlayer player : server.getPlayerList().getPlayers()) {
                JjkData.get(player).ifPresent(data -> {
                    if (data.cursedEnergy() < data.maxCursedEnergy()) {
                        JjkData.set(player, data.withCursedEnergy(
                                data.cursedEnergy() + data.character().regenPerSecond()));
                    }
                });
            }
        });
    }
}
