package com.example.jjk.client;

import com.example.jjk.JjkMod;
import com.example.jjk.data.ModAttachments;
import com.example.jjk.data.PlayerJjkData;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.network.chat.Component;

/** Шкала проклятой энергии и подсказки по клавишам — левый верхний угол. */
public final class EnergyHud {
    private static final int X = 10;
    private static final int Y = 10;
    private static final int BAR_WIDTH = 110;
    private static final int BAR_HEIGHT = 8;

    private EnergyHud() {
    }

    public static void register() {
        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT, JjkMod.id("cursed_energy"), EnergyHud::extract);
    }

    private static void extract(GuiGraphicsExtractor graphics, DeltaTracker tickCounter) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) {
            return;
        }
        PlayerJjkData data = mc.player.getAttached(ModAttachments.PLAYER_DATA);
        if (data == null) {
            return;
        }

        graphics.text(mc.font, data.character().displayName(), X, Y, 0xFFFFFFFF, true);
        graphics.text(mc.font,
                Component.translatable("hud.jjkmod.energy", data.cursedEnergy(), data.maxCursedEnergy()),
                X, Y + 11, 0xFF9CC8FF, true);

        int barY = Y + 23;
        int max = Math.max(1, data.maxCursedEnergy());
        int filled = (int) ((long) BAR_WIDTH * data.cursedEnergy() / max);
        graphics.fill(X - 1, barY - 1, X + BAR_WIDTH + 1, barY + BAR_HEIGHT + 1, 0xFF000000);
        graphics.fill(X, barY, X + BAR_WIDTH, barY + BAR_HEIGHT, 0xFF1A1A2E);
        graphics.fill(X, barY, X + filled, barY + BAR_HEIGHT, 0xFF3AA0FF);

        int lineY = barY + BAR_HEIGHT + 6;
        lineY = hint(graphics, mc, ModKeys.TECHNIQUE_1, data.character().technique(0).displayName(), lineY);
        lineY = hint(graphics, mc, ModKeys.TECHNIQUE_2, data.character().technique(1).displayName(), lineY);
        hint(graphics, mc, ModKeys.REVERSE_TECHNIQUE, Component.translatable("technique.jjkmod.reverse"), lineY);
    }

    private static int hint(GuiGraphicsExtractor graphics, Minecraft mc, KeyMapping key, Component name, int y) {
        Component line = Component.empty()
                .append("[")
                .append(key.getTranslatedKeyMessage())
                .append("] ")
                .append(name);
        graphics.text(mc.font, line, X, y, 0xFFE0E0E0, true);
        return y + 10;
    }
}
