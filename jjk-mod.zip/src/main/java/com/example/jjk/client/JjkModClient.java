package com.example.jjk.client;

import com.example.jjk.network.OpenCharacterSelectPayload;
import com.example.jjk.network.UseTechniquePayload;
import com.example.jjk.technique.TechniqueExecutor;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.KeyMapping;

public class JjkModClient implements ClientModInitializer {
    /**
     * Пакет может прийти, пока клиент ещё показывает экран загрузки мира —
     * открытие экрана в этот момент было бы перезаписано. Поэтому лишь ставим флаг
     * и открываем меню на тике, когда мир загружен и нет другого экрана.
     */
    private static boolean pendingOpen;

    @Override
    public void onInitializeClient() {
        ModKeys.init();
        EnergyHud.register();

        ClientPlayNetworking.registerGlobalReceiver(OpenCharacterSelectPayload.TYPE,
                (payload, context) -> {
                    if (!(context.client().gui.screen() instanceof CharacterSelectScreen)) {
                        pendingOpen = true;
                    }
                });

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null || client.level == null) {
                return;
            }
            if (pendingOpen && client.gui.screen() == null) {
                pendingOpen = false;
                client.gui.setScreen(new CharacterSelectScreen()); // в 26.2 экраны переехали из Minecraft в Gui
            }
            sendPresses(ModKeys.TECHNIQUE_1, 0);
            sendPresses(ModKeys.TECHNIQUE_2, 1);
            sendPresses(ModKeys.REVERSE_TECHNIQUE, TechniqueExecutor.RCT_SLOT);
        });

        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> pendingOpen = false);
    }

    /** Один пакет на нажатие; всё остальное (энергия, перезарядка) проверяет сервер. */
    private static void sendPresses(KeyMapping key, int slot) {
        while (key.consumeClick()) {
            ClientPlayNetworking.send(new UseTechniquePayload(slot));
        }
    }
}
