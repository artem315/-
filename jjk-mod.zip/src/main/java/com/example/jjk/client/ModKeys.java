package com.example.jjk.client;

import com.example.jjk.JjkMod;
import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.minecraft.client.KeyMapping;

/** Клавиши: Z — 1-я техника, X — 2-я техника, C — обратная проклятая техника (лечение). Переназначаются в настройках. */
public final class ModKeys {
    private static final KeyMapping.Category CATEGORY = KeyMapping.Category.register(JjkMod.id("main"));

    public static final KeyMapping TECHNIQUE_1 = register("technique_1", InputConstants.KEY_Z);
    public static final KeyMapping TECHNIQUE_2 = register("technique_2", InputConstants.KEY_X);
    public static final KeyMapping REVERSE_TECHNIQUE = register("reverse_technique", InputConstants.KEY_C);

    private ModKeys() {
    }

    private static KeyMapping register(String name, int key) {
        return KeyMappingHelper.registerKeyMapping(
                new KeyMapping("key.jjkmod." + name, InputConstants.Type.KEYSYM, key, CATEGORY));
    }

    /** Вызов гарантирует загрузку класса и регистрацию клавиш. */
    public static void init() {
    }
}
