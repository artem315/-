package com.example.jjk.technique;

import net.minecraft.network.chat.Component;

public enum Technique {
    // id, тип, стоимость CE, перезарядка (тики), дальность, урон, отбрасывание
    BLUE("blue", Kind.PULL, 150, 120, 10.0, 3.0, 0.0),
    RED("red", Kind.BLAST, 250, 200, 8.0, 12.0, 1.6),
    DISMANTLE("dismantle", Kind.SLASH, 100, 60, 14.0, 9.0, 0.0),
    CLEAVE("cleave", Kind.STRIKE, 300, 160, 6.0, 20.0, 0.8),
    DIVERGENT_FIST("divergent_fist", Kind.STRIKE, 60, 40, 3.5, 7.0, 1.0),
    BLACK_FLASH("black_flash", Kind.STRIKE, 250, 240, 4.5, 24.0, 1.5);

    /** Как техника выбирает цели. coneDot — минимальный cos угла между взглядом и целью. */
    public enum Kind {
        PULL(0.3),    // притягивает цели впереди к точке перед игроком
        BLAST(0.6),   // широкий конус: урон + отбрасывание
        SLASH(0.93),  // узкий луч: урон всем на линии
        STRIKE(0.85); // один удар по ближайшей цели

        private final double coneDot;

        Kind(double coneDot) {
            this.coneDot = coneDot;
        }

        public double coneDot() {
            return coneDot;
        }
    }

    private final String id;
    private final Kind kind;
    private final int cost;
    private final int cooldownTicks;
    private final double range;
    private final double damage;
    private final double knockback;

    Technique(String id, Kind kind, int cost, int cooldownTicks, double range, double damage, double knockback) {
        this.id = id;
        this.kind = kind;
        this.cost = cost;
        this.cooldownTicks = cooldownTicks;
        this.range = range;
        this.damage = damage;
        this.knockback = knockback;
    }

    public String id() { return id; }
    public Kind kind() { return kind; }
    public int cost() { return cost; }
    public int cooldownTicks() { return cooldownTicks; }
    public double range() { return range; }
    public double damage() { return damage; }
    public double knockback() { return knockback; }

    public Component displayName() {
        return Component.translatable("technique.jjkmod." + id);
    }
}
