package com.example.jjk.technique;

import com.example.jjk.JjkMod;
import com.example.jjk.data.JjkData;
import com.example.jjk.data.PlayerJjkData;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

/** Вся игровая логика техник — только на сервере. Клиент шлёт лишь номер слота. */
public final class TechniqueExecutor {
    /** Слоты 0 и 1 — техники персонажа, слот 2 — обратная проклятая техника (лечение). */
    public static final int RCT_SLOT = 2;
    private static final int RCT_COST = 200;
    private static final int RCT_COOLDOWN_TICKS = 100;
    private static final float RCT_HEAL = 6.0f;

    /** Игровое время (тики), когда слот снова готов. Не сохраняется на диск. */
    private static final Map<UUID, long[]> COOLDOWNS = new HashMap<>();

    private TechniqueExecutor() {
    }

    public static void clearCooldowns(UUID playerId) {
        COOLDOWNS.remove(playerId);
    }

    public static void use(ServerPlayer player, int slot) {
        // 1) Валидация ввода клиента
        if (slot < 0 || slot > RCT_SLOT) {
            JjkMod.LOGGER.warn("{} sent invalid technique slot {}", player.getGameProfile().name(), slot);
            return;
        }
        if (!player.isAlive() || player.isSpectator()) {
            return;
        }
        if (!(player.level() instanceof ServerLevel level)) {
            return;
        }
        Optional<PlayerJjkData> optData = JjkData.get(player);
        if (optData.isEmpty()) {
            return; // персонаж ещё не выбран
        }
        PlayerJjkData data = optData.get();

        // 2) Перезарядка и энергия проверяются на сервере
        long now = level.getGameTime();
        long[] ready = COOLDOWNS.computeIfAbsent(player.getUUID(), id -> new long[RCT_SLOT + 1]);
        if (now < ready[slot]) {
            long seconds = (ready[slot] - now + 19) / 20;
            player.sendSystemMessage(Component.translatable("message.jjkmod.cooldown", seconds), true);
            return;
        }

        Technique technique = slot == RCT_SLOT ? null : data.character().technique(slot);
        int cost = technique == null ? RCT_COST : technique.cost();
        int cooldown = technique == null ? RCT_COOLDOWN_TICKS : technique.cooldownTicks();
        if (data.cursedEnergy() < cost) {
            player.sendSystemMessage(Component.translatable("message.jjkmod.not_enough_energy"), true);
            return;
        }

        // 3) Выполнение
        boolean success = technique == null ? reverseTechnique(player, level) : cast(player, level, technique);
        if (!success) {
            return;
        }
        JjkData.set(player, data.withCursedEnergy(data.cursedEnergy() - cost));
        ready[slot] = now + cooldown;
    }

    private static boolean reverseTechnique(ServerPlayer player, ServerLevel level) {
        if (player.getHealth() >= player.getMaxHealth()) {
            player.sendSystemMessage(Component.translatable("message.jjkmod.full_health"), true);
            return false;
        }
        player.heal(RCT_HEAL);
        level.sendParticles(ParticleTypes.HEART, player.getX(), player.getY() + 1.0, player.getZ(),
                6, 0.4, 0.5, 0.4, 0.0);
        return true;
    }

    private static boolean cast(ServerPlayer player, ServerLevel level, Technique technique) {
        Vec3 eye = player.getEyePosition();
        Vec3 look = player.getLookAngle().normalize();
        List<LivingEntity> targets = targetsInCone(player, level, eye, look,
                technique.range(), technique.kind().coneDot());

        Vec3 front = eye.add(look.scale(1.5));
        SoundEvent sound;

        switch (technique.kind()) {
            case PULL -> {
                Vec3 anchor = eye.add(look.scale(3.0));
                for (LivingEntity target : targets) {
                    Vec3 pull = anchor.subtract(target.position()).scale(0.3);
                    double length = pull.length();
                    if (length > 1.5) {
                        pull = pull.scale(1.5 / length);
                    }
                    target.push(pull.x(), pull.y() + 0.05, pull.z());
                    damage(player, level, target, technique.damage());
                }
                level.sendParticles(ParticleTypes.EXPLOSION, anchor.x(), anchor.y(), anchor.z(), 1, 0, 0, 0, 0);
                sound = SoundEvents.ENDERMAN_TELEPORT;
            }
            case BLAST -> {
                for (LivingEntity target : targets) {
                    damage(player, level, target, technique.damage());
                    target.push(look.x() * technique.knockback(), 0.35, look.z() * technique.knockback());
                }
                level.sendParticles(ParticleTypes.EXPLOSION, front.x(), front.y(), front.z(), 1, 0, 0, 0, 0);
                sound = SoundEvents.PLAYER_ATTACK_STRONG;
            }
            case SLASH -> {
                for (LivingEntity target : targets) {
                    damage(player, level, target, technique.damage());
                }
                level.sendParticles(ParticleTypes.SWEEP_ATTACK, front.x(), front.y(), front.z(), 1, 0, 0, 0, 0);
                sound = SoundEvents.PLAYER_ATTACK_SWEEP;
            }
            case STRIKE -> {
                if (!targets.isEmpty()) {
                    LivingEntity target = targets.get(0);
                    damage(player, level, target, technique.damage());
                    target.push(look.x() * technique.knockback(), 0.3, look.z() * technique.knockback());
                }
                level.sendParticles(ParticleTypes.SWEEP_ATTACK, front.x(), front.y(), front.z(), 1, 0, 0, 0, 0);
                sound = SoundEvents.PLAYER_ATTACK_CRIT;
            }
            default -> throw new IllegalStateException("Unhandled kind " + technique.kind());
        }

        List<LivingEntity> hit = technique.kind() == Technique.Kind.STRIKE && !targets.isEmpty()
                ? targets.subList(0, 1) : targets;
        for (LivingEntity target : hit) {
            Vec3 c = target.getBoundingBox().getCenter();
            level.sendParticles(ParticleTypes.CRIT, c.x(), c.y(), c.z(), 10, 0.3, 0.3, 0.3, 0.2);
        }
        level.playSound(null, player.blockPosition(), sound, SoundSource.PLAYERS, 1.0f, 1.0f);
        return true;
    }

    private static void damage(ServerPlayer player, ServerLevel level, LivingEntity target, double amount) {
        if (amount > 0) {
            target.hurtServer(level, level.damageSources().playerAttack(player), (float) amount);
        }
    }

    /** Живые цели в конусе перед игроком, отсортированные по расстоянию. */
    private static List<LivingEntity> targetsInCone(ServerPlayer player, ServerLevel level,
                                                    Vec3 eye, Vec3 look, double range, double minDot) {
        AABB box = player.getBoundingBox().inflate(range);
        List<LivingEntity> found = level.getEntitiesOfClass(LivingEntity.class, box,
                e -> e != player && e.isAlive() && !e.isSpectator());
        List<LivingEntity> result = new ArrayList<>();
        for (LivingEntity entity : found) {
            Vec3 to = entity.getBoundingBox().getCenter().subtract(eye);
            double distance = to.length();
            if (distance > range || distance < 1.0E-4) {
                continue;
            }
            if (to.scale(1.0 / distance).dot(look) >= minDot) {
                result.add(entity);
            }
        }
        result.sort(Comparator.comparingDouble((LivingEntity e) -> e.distanceToSqr(player)));
        return result;
    }
}
