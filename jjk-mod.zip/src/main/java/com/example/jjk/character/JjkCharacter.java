package com.example.jjk.character;

import com.example.jjk.technique.Technique;
import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import net.minecraft.network.chat.Component;

import java.util.List;
import java.util.Optional;

public enum JjkCharacter {
    GOJO("satoru_gojo", 1000, 20, Technique.BLUE, Technique.RED),
    SUKUNA("ryomen_sukuna", 1500, 25, Technique.DISMANTLE, Technique.CLEAVE),
    ITADORI("yuji_itadori", 600, 8, Technique.DIVERGENT_FIST, Technique.BLACK_FLASH);

    public static final Codec<JjkCharacter> CODEC = Codec.STRING.comapFlatMap(
            id -> byId(id).map(DataResult::success)
                    .orElseGet(() -> DataResult.error(() -> "Unknown JJK character: " + id)),
            JjkCharacter::id);

    private final String id;
    private final int baseCursedEnergy;
    private final int regenPerSecond;
    private final List<Technique> techniques;

    JjkCharacter(String id, int baseCursedEnergy, int regenPerSecond, Technique first, Technique second) {
        this.id = id;
        this.baseCursedEnergy = baseCursedEnergy;
        this.regenPerSecond = regenPerSecond;
        this.techniques = List.of(first, second);
    }

    public String id() {
        return id;
    }

    public int baseCursedEnergy() {
        return baseCursedEnergy;
    }

    public int regenPerSecond() {
        return regenPerSecond;
    }

    /** slot: 0 или 1. */
    public Technique technique(int slot) {
        return techniques.get(slot);
    }

    public Component displayName() {
        return Component.translatable("character.jjkmod." + id);
    }

    public Component description() {
        return Component.translatable("character.jjkmod." + id + ".desc");
    }

    public static Optional<JjkCharacter> byId(String id) {
        for (JjkCharacter c : values()) {
            if (c.id.equals(id)) {
                return Optional.of(c);
            }
        }
        return Optional.empty();
    }
}
