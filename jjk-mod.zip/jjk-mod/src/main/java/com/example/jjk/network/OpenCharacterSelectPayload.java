package com.example.jjk.network;

import com.example.jjk.JjkMod;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/** S2C: сервер требует открыть меню выбора персонажа. Данных нет. */
public record OpenCharacterSelectPayload() implements CustomPacketPayload {
    public static final CustomPacketPayload.Type<OpenCharacterSelectPayload> TYPE =
            new CustomPacketPayload.Type<>(JjkMod.id("open_character_select"));

    public static final StreamCodec<RegistryFriendlyByteBuf, OpenCharacterSelectPayload> CODEC =
            StreamCodec.unit(new OpenCharacterSelectPayload());

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
