package com.example.jjk.network;

import com.example.jjk.JjkMod;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/** C2S: клиент просит выбрать персонажа. Строка ограничена по длине (защита от мусорных пакетов). */
public record CharacterSelectPayload(String characterId) implements CustomPacketPayload {
    public static final CustomPacketPayload.Type<CharacterSelectPayload> TYPE =
            new CustomPacketPayload.Type<>(JjkMod.id("character_select"));

    public static final StreamCodec<RegistryFriendlyByteBuf, CharacterSelectPayload> CODEC =
            StreamCodec.composite(
                    ByteBufCodecs.stringUtf8(32), CharacterSelectPayload::characterId,
                    CharacterSelectPayload::new);

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
