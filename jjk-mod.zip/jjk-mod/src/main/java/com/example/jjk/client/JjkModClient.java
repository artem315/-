package com.example.jjk.client;

import com.example.jjk.network.OpenCharacterSelectPayload;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;

public class JjkModClient implements ClientModInitializer {
    /**
     * Пакет может прийти, пока клиент ещё показывает экран загрузки мира —
     * setScreen в этот момент был бы перезаписан. Поэтому лишь ставим флаг
     * и открываем меню на тике, когда мир загружен и нет другого экрана.
     */
    private static boolean pendingOpen;

    @Override
    public void onInitializeClient() {
        ClientPlayNetworking.registerGlobalReceiver(OpenCharacterSelectPayload.TYPE,
                (payload, context) -> {
                    if (!(context.client().gui.screen() instanceof CharacterSelectScreen)) {
                        pendingOpen = true;
                    }
                });

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (pendingOpen && client.player != null && client.level != null && client.gui.screen() == null) {
                pendingOpen = false;
                client.gui.setScreen(new CharacterSelectScreen()); // в 26.2 экраны переехали из Minecraft в Gui
            }
        });

        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> pendingOpen = false);
    }
}
