package com.example.jjk.network;

import com.example.jjk.JjkMod;
import com.example.jjk.character.JjkCharacter;
import com.example.jjk.data.JjkData;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

import java.util.Optional;

public final class ModNetworking {
    private ModNetworking() {
    }

    /** Регистрация типов пакетов — выполняется и на клиенте, и на сервере (common-инициализатор). */
    public static void registerPayloads() {
        PayloadTypeRegistry.clientboundPlay().register(OpenCharacterSelectPayload.TYPE, OpenCharacterSelectPayload.CODEC);
        PayloadTypeRegistry.serverboundPlay().register(CharacterSelectPayload.TYPE, CharacterSelectPayload.CODEC);
    }

    public static void registerServerReceivers() {
        // Обработчик вызывается в серверном потоке — безопасно менять состояние игрока.
        ServerPlayNetworking.registerGlobalReceiver(CharacterSelectPayload.TYPE,
                (payload, context) -> handleSelect(payload, context.player()));
    }

    private static void handleSelect(CharacterSelectPayload payload, ServerPlayer player) {
        // 1) Повторный выбор запрещён (защита от смены персонажа читом).
        if (JjkData.hasCharacter(player)) {
            JjkMod.LOGGER.warn("{} tried to select a character twice", player.getGameProfile().name());
            return;
        }

        // 2) Валидация id: клиенту нельзя доверять.
        Optional<JjkCharacter> chosen = JjkCharacter.byId(payload.characterId());
        if (chosen.isEmpty()) {
            JjkMod.LOGGER.warn("{} sent invalid character id '{}'", player.getGameProfile().name(), payload.characterId());
            requestSelection(player);
            return;
        }

        // 3) Сервер сам определяет стартовые значения (клиент их не присылает).
        JjkData.assign(player, chosen.get());
        player.sendSystemMessage(Component.translatable("message.jjkmod.character_selected", chosen.get().displayName()));
    }

    /** Просит клиента открыть меню (только если у клиента установлен мод). */
    public static void requestSelection(ServerPlayer player) {
        if (ServerPlayNetworking.canSend(player, OpenCharacterSelectPayload.TYPE)) {
            ServerPlayNetworking.send(player, new OpenCharacterSelectPayload());
        }
    }
}
