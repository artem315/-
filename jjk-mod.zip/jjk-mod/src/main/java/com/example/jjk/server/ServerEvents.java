package com.example.jjk.server;

import com.example.jjk.data.JjkData;
import com.example.jjk.network.ModNetworking;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.server.level.ServerPlayer;

public final class ServerEvents {
    private ServerEvents() {
    }

    public static void register() {
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            ServerPlayer player = handler.getPlayer();
            if (!JjkData.hasCharacter(player)) {
                ModNetworking.requestSelection(player);
            }
        });
    }
}
