package com.example.jjk.data;

import com.example.jjk.character.JjkCharacter;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;

public record PlayerJjkData(JjkCharacter character, int cursedEnergy, int maxCursedEnergy) {
    public static final Codec<PlayerJjkData> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            JjkCharacter.CODEC.fieldOf("character").forGetter(PlayerJjkData::character),
            Codec.INT.fieldOf("cursed_energy").forGetter(PlayerJjkData::cursedEnergy),
            Codec.INT.fieldOf("max_cursed_energy").forGetter(PlayerJjkData::maxCursedEnergy)
    ).apply(instance, PlayerJjkData::new));

    public static PlayerJjkData initial(JjkCharacter character) {
        int base = character.baseCursedEnergy();
        return new PlayerJjkData(character, base, base);
    }

    public PlayerJjkData withCursedEnergy(int value) {
        return new PlayerJjkData(character, Math.max(0, Math.min(value, maxCursedEnergy)), maxCursedEnergy);
    }
}
