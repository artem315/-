package com.example.jjk;

import com.example.jjk.data.ModAttachments;
import com.example.jjk.network.ModNetworking;
import com.example.jjk.server.ServerEvents;
import net.fabricmc.api.ModInitializer;
import net.minecraft.resources.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class JjkMod implements ModInitializer {
    public static final String MOD_ID = "jjkmod";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static Identifier id(String path) {
        return Identifier.fromNamespaceAndPath(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        ModAttachments.init();
        // Порядок важен: сначала типы пакетов, потом приёмники.
        ModNetworking.registerPayloads();
        ModNetworking.registerServerReceivers();
        ServerEvents.register();
        LOGGER.info("JJK mod initialized");
    }
}
