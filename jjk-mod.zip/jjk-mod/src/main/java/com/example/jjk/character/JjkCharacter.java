package com.example.jjk.character;

import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import net.minecraft.network.chat.Component;

import java.util.Optional;

public enum JjkCharacter {
    GOJO("satoru_gojo", 1000),
    SUKUNA("ryomen_sukuna", 1500),
    ITADORI("yuji_itadori", 600);

    public static final Codec<JjkCharacter> CODEC = Codec.STRING.comapFlatMap(
            id -> byId(id).map(DataResult::success)
                    .orElseGet(() -> DataResult.error(() -> "Unknown JJK character: " + id)),
            JjkCharacter::id);

    private final String id;
    private final int baseCursedEnergy;

    JjkCharacter(String id, int baseCursedEnergy) {
        this.id = id;
        this.baseCursedEnergy = baseCursedEnergy;
    }

    public String id() {
        return id;
    }

    public int baseCursedEnergy() {
        return baseCursedEnergy;
    }

    public Component displayName() {
        return Component.translatable("character.jjkmod." + id);
    }

    public Component description() {
        return Component.translatable("character.jjkmod." + id + ".desc");
    }

    public static Optional<JjkCharacter> byId(String id) {
        for (JjkCharacter c : values()) {
            if (c.id.equals(id)) {
                return Optional.of(c);
            }
        }
        return Optional.empty();
    }
}
