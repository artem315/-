package com.example.jjk.data;

import com.example.jjk.character.JjkCharacter;
import net.minecraft.server.level.ServerPlayer;

import java.util.Optional;

public final class JjkData {
    private JjkData() {
    }

    public static Optional<PlayerJjkData> get(ServerPlayer player) {
        return Optional.ofNullable(player.getAttached(ModAttachments.PLAYER_DATA));
    }

    public static boolean hasCharacter(ServerPlayer player) {
        return player.hasAttached(ModAttachments.PLAYER_DATA);
    }

    public static void assign(ServerPlayer player, JjkCharacter character) {
        player.setAttached(ModAttachments.PLAYER_DATA, PlayerJjkData.initial(character));
    }
}
