package com.example.jjk.client;

import com.example.jjk.character.JjkCharacter;
import com.example.jjk.network.CharacterSelectPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.StringWidget;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.layouts.FrameLayout;
import net.minecraft.client.gui.layouts.LinearLayout;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class CharacterSelectScreen extends Screen {
    private LinearLayout layout;

    public CharacterSelectScreen() {
        super(Component.translatable("screen.jjkmod.character_select"));
    }

    @Override
    protected void init() {
        layout = LinearLayout.vertical().spacing(8);
        layout.defaultCellSetting().alignHorizontallyCenter();

        layout.addChild(new StringWidget(this.title, this.font));
        layout.addChild(new StringWidget(
                Component.translatable("screen.jjkmod.character_select.subtitle"), this.font));

        for (JjkCharacter character : JjkCharacter.values()) {
            layout.addChild(Button.builder(character.displayName(), button -> select(character))
                    .width(200)
                    .tooltip(Tooltip.create(character.description()))
                    .build());
        }

        layout.visitWidgets(this::addRenderableWidget);
        repositionElements();
    }

    @Override
    protected void repositionElements() {
        layout.arrangeElements();
        FrameLayout.centerInRectangle(layout, this.getRectangle());
    }

    private void select(JjkCharacter character) {
        ClientPlayNetworking.send(new CharacterSelectPayload(character.id()));
        // Если сервер отклонит выбор — он пришлёт OpenCharacterSelectPayload и меню откроется снова.
        this.onClose();
    }

    /** ESC не закрывает экран: персонаж ещё не выбран. */
    @Override
    public boolean shouldCloseOnEsc() {
        return false;
    }
}
