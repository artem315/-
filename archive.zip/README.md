# JJK Fabric 26.2 Starter

A Fabric mod starter for Minecraft 26.2 with Java 25, server-authoritative first-login character selection, persistent SavedData, modern CustomPacketPayload networking, and GitHub Actions builds.

## Characters
- Satoru Gojo — 1000 Cursed Energy
- Ryomen Sukuna — 1200 Cursed Energy
- Yuji Itadori — 700 Cursed Energy

## Build
Java 25 is required for Minecraft 26.2.

Linux/macOS:
```bash
chmod +x gradlew
./gradlew build
```

Windows:
```bat
gradlew.bat build
```

The mod jar will be created in `build/libs/`.

## Toolchain
- Minecraft 26.2
- Fabric Loader 0.19.5
- Fabric API 0.161.0+26.2
- Fabric Loom 1.18-SNAPSHOT
- Java 25
- Gradle 9.7.1

Minecraft 26.1+ is unobfuscated, so Yarn mappings are intentionally not used. The `yarn_mappings` property is retained only as a note for the requested project shape.

## Wrapper note
The included `gradle-wrapper.jar` is a tiny self-contained bootstrap launcher. It reads `gradle-wrapper.properties`, downloads Gradle 9.7.1 from the official Gradle distribution URL on first run, and delegates to it. This keeps `./gradlew build` working without committing the upstream Gradle binary wrapper.
