package dev.artyonix.jjk.state;

import com.mojang.serialization.Codec;
import dev.artyonix.jjk.JjkMod;
import dev.artyonix.jjk.character.JjkCharacter;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraft.world.level.saveddata.SavedDataType;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

public final class JjkPlayerState extends SavedData {
    private final Map<UUID, PlayerJujutsuData> players = new HashMap<>();

    public JjkPlayerState() {
    }

    private JjkPlayerState(List<PlayerJujutsuData> savedPlayers) {
        for (PlayerJujutsuData data : savedPlayers) {
            players.put(data.playerId(), data);
        }
    }

    private static final Codec<JjkPlayerState> CODEC = PlayerJujutsuData.CODEC
            .listOf()
            .xmap(
                    JjkPlayerState::new,
                    state -> List.copyOf(state.players.values())
            );

    private static final SavedDataType<JjkPlayerState> TYPE = new SavedDataType<>(
            JjkMod.id("player_jujutsu_data"),
            JjkPlayerState::new,
            CODEC,
            null
    );

    public static JjkPlayerState get(MinecraftServer server) {
        ServerLevel overworld = server.getLevel(ServerLevel.OVERWORLD);

        if (overworld == null) {
            throw new IllegalStateException("Overworld is not available");
        }

        return overworld.getDataStorage().computeIfAbsent(TYPE);
    }

    public Optional<PlayerJujutsuData> getPlayer(UUID playerId) {
        return Optional.ofNullable(players.get(playerId));
    }

    public boolean hasCharacter(UUID playerId) {
        return players.containsKey(playerId);
    }

    public boolean selectCharacter(UUID playerId, JjkCharacter character) {
        if (players.containsKey(playerId)) {
            return false;
        }

        players.put(
                playerId,
                new PlayerJujutsuData(playerId, character, character.baseCursedEnergy())
        );
        setDirty();
        return true;
    }

    public boolean setCursedEnergy(UUID playerId, int cursedEnergy) {
        PlayerJujutsuData current = players.get(playerId);
        if (current == null) {
            return false;
        }

        int safeValue = Math.max(0, cursedEnergy);
        players.put(
                playerId,
                new PlayerJujutsuData(playerId, current.character(), safeValue)
        );
        setDirty();
        return true;
    }
}
