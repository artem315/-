package dev.artyonix.jjk.state;

import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.artyonix.jjk.character.JjkCharacter;

import java.util.UUID;

public record PlayerJujutsuData(
        UUID playerId,
        JjkCharacter character,
        int cursedEnergy
) {
    private static final Codec<UUID> UUID_CODEC = Codec.STRING.comapFlatMap(
            value -> {
                try {
                    return DataResult.success(UUID.fromString(value));
                } catch (IllegalArgumentException exception) {
                    return DataResult.error(() -> "Invalid UUID: " + value);
                }
            },
            UUID::toString
    );

    public static final Codec<PlayerJujutsuData> CODEC = RecordCodecBuilder.create(instance ->
            instance.group(
                    UUID_CODEC.fieldOf("player").forGetter(PlayerJujutsuData::playerId),
                    JjkCharacter.CODEC.fieldOf("character").forGetter(PlayerJujutsuData::character),
                    Codec.INT.fieldOf("cursed_energy").forGetter(PlayerJujutsuData::cursedEnergy)
            ).apply(instance, PlayerJujutsuData::new)
    );
}
