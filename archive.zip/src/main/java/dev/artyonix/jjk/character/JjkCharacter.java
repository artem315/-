package dev.artyonix.jjk.character;

import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;

import java.util.Arrays;
import java.util.Optional;

public enum JjkCharacter {
    SATORU_GOJO("satoru_gojo", "character.jjkmod.satoru_gojo", 1000),
    RYOMEN_SUKUNA("ryomen_sukuna", "character.jjkmod.ryomen_sukuna", 1200),
    YUJI_ITADORI("yuji_itadori", "character.jjkmod.yuji_itadori", 700);

    private final String id;
    private final String translationKey;
    private final int baseCursedEnergy;

    JjkCharacter(String id, String translationKey, int baseCursedEnergy) {
        this.id = id;
        this.translationKey = translationKey;
        this.baseCursedEnergy = baseCursedEnergy;
    }

    public String id() {
        return id;
    }

    public String translationKey() {
        return translationKey;
    }

    public int baseCursedEnergy() {
        return baseCursedEnergy;
    }

    public static Optional<JjkCharacter> byId(String id) {
        if (id == null) {
            return Optional.empty();
        }

        return Arrays.stream(values())
                .filter(character -> character.id.equals(id))
                .findFirst();
    }

    public static final Codec<JjkCharacter> CODEC = Codec.STRING.comapFlatMap(
            id -> byId(id)
                    .map(DataResult::success)
                    .orElseGet(() -> DataResult.error(() -> "Unknown JJK character: " + id)),
            JjkCharacter::id
    );
}
