package dev.artyonix.jjk;

import dev.artyonix.jjk.network.CharacterStatePayload;
import dev.artyonix.jjk.network.JjkNetworking;
import dev.artyonix.jjk.state.JjkPlayerState;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerPlayer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class JjkMod implements ModInitializer {
    public static final String MOD_ID = "jjkmod";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static Identifier id(String path) {
        return Identifier.fromNamespaceAndPath(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        LOGGER.info("Initializing JJK Mod");

        JjkNetworking.registerPayloadTypes();
        JjkNetworking.registerServerReceivers();

        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            ServerPlayer player = handler.player;
            JjkPlayerState state = JjkPlayerState.get(server);

            state.getPlayer(player.getUUID()).ifPresentOrElse(
                    data -> ServerPlayNetworking.send(
                            player,
                            CharacterStatePayload.selected(data)
                    ),
                    () -> ServerPlayNetworking.send(
                            player,
                            CharacterStatePayload.selectionRequired()
                    )
            );
        });
    }
}
