package dev.artyonix.jjk.network;

import dev.artyonix.jjk.JjkMod;
import dev.artyonix.jjk.character.JjkCharacter;
import dev.artyonix.jjk.state.JjkPlayerState;
import dev.artyonix.jjk.state.PlayerJujutsuData;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.level.ServerPlayer;

import java.util.Optional;

public final class JjkNetworking {
    private static final int MAX_CHARACTER_ID_LENGTH = 32;

    private JjkNetworking() {
    }

    public static void registerPayloadTypes() {
        PayloadTypeRegistry.serverboundPlay().register(
                CharacterSelectPayload.TYPE,
                CharacterSelectPayload.CODEC
        );

        PayloadTypeRegistry.clientboundPlay().register(
                CharacterStatePayload.TYPE,
                CharacterStatePayload.CODEC
        );
    }

    public static void registerServerReceivers() {
        ServerPlayNetworking.registerGlobalReceiver(
                CharacterSelectPayload.TYPE,
                JjkNetworking::handleCharacterSelection
        );
    }

    private static void handleCharacterSelection(
            CharacterSelectPayload payload,
            ServerPlayNetworking.Context context
    ) {
        ServerPlayer player = context.player();
        String requestedId = payload.characterId();

        if (requestedId == null
                || requestedId.isBlank()
                || requestedId.length() > MAX_CHARACTER_ID_LENGTH) {
            JjkMod.LOGGER.warn(
                    "Player {} sent an invalid character id",
                    player.getGameProfile().getName()
            );
            ServerPlayNetworking.send(player, CharacterStatePayload.selectionRequired());
            return;
        }

        JjkPlayerState state = JjkPlayerState.get(context.server());
        Optional<PlayerJujutsuData> existing = state.getPlayer(player.getUUID());

        if (existing.isPresent()) {
            ServerPlayNetworking.send(player, CharacterStatePayload.selected(existing.get()));
            return;
        }

        Optional<JjkCharacter> requestedCharacter = JjkCharacter.byId(requestedId);
        if (requestedCharacter.isEmpty()) {
            JjkMod.LOGGER.warn(
                    "Player {} attempted to select unknown character '{}'",
                    player.getGameProfile().getName(),
                    requestedId
            );
            ServerPlayNetworking.send(player, CharacterStatePayload.selectionRequired());
            return;
        }

        JjkCharacter character = requestedCharacter.get();
        if (!state.selectCharacter(player.getUUID(), character)) {
            state.getPlayer(player.getUUID()).ifPresent(data ->
                    ServerPlayNetworking.send(player, CharacterStatePayload.selected(data))
            );
            return;
        }

        PlayerJujutsuData data = state.getPlayer(player.getUUID()).orElseThrow();
        JjkMod.LOGGER.info(
                "{} selected {} with {} cursed energy",
                player.getGameProfile().getName(),
                character.id(),
                data.cursedEnergy()
        );
        ServerPlayNetworking.send(player, CharacterStatePayload.selected(data));
    }
}
