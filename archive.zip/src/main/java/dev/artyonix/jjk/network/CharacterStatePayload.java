package dev.artyonix.jjk.network;

import dev.artyonix.jjk.JjkMod;
import dev.artyonix.jjk.state.PlayerJujutsuData;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

public record CharacterStatePayload(
        boolean selectionRequired,
        String characterId,
        int cursedEnergy
) implements CustomPacketPayload {
    public static final Identifier ID = JjkMod.id("character_state");
    public static final Type<CharacterStatePayload> TYPE = new Type<>(ID);

    public static final StreamCodec<RegistryFriendlyByteBuf, CharacterStatePayload> CODEC =
            StreamCodec.composite(
                    ByteBufCodecs.BOOL,
                    CharacterStatePayload::selectionRequired,
                    ByteBufCodecs.STRING_UTF8,
                    CharacterStatePayload::characterId,
                    ByteBufCodecs.VAR_INT,
                    CharacterStatePayload::cursedEnergy,
                    CharacterStatePayload::new
            );

    public static CharacterStatePayload selectionRequired() {
        return new CharacterStatePayload(true, "", 0);
    }

    public static CharacterStatePayload selected(PlayerJujutsuData data) {
        return new CharacterStatePayload(false, data.character().id(), data.cursedEnergy());
    }

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
