package dev.artyonix.jjk.network;

import dev.artyonix.jjk.JjkMod;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

public record CharacterSelectPayload(String characterId) implements CustomPacketPayload {
    public static final Identifier ID = JjkMod.id("select_character");
    public static final Type<CharacterSelectPayload> TYPE = new Type<>(ID);

    public static final StreamCodec<RegistryFriendlyByteBuf, CharacterSelectPayload> CODEC =
            StreamCodec.composite(
                    ByteBufCodecs.STRING_UTF8,
                    CharacterSelectPayload::characterId,
                    CharacterSelectPayload::new
            );

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
