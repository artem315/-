package dev.artyonix.jjk.client.gui;

import dev.artyonix.jjk.character.JjkCharacter;
import dev.artyonix.jjk.network.CharacterSelectPayload;
import dev.artyonix.jjk.network.CharacterStatePayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public final class CharacterSelectScreen extends Screen {
    private boolean selectionConfirmed = false;
    private boolean requestInFlight = false;
    private Component status = Component.translatable("screen.jjkmod.choose_character");

    public CharacterSelectScreen() {
        super(Component.translatable("screen.jjkmod.character_selection"));
    }

    @Override
    protected void init() {
        int buttonWidth = 240;
        int buttonHeight = 20;
        int x = (this.width - buttonWidth) / 2;
        int startY = this.height / 2 - 45;
        int spacing = 26;

        addCharacterButton(JjkCharacter.SATORU_GOJO, x, startY, buttonWidth, buttonHeight);
        addCharacterButton(JjkCharacter.RYOMEN_SUKUNA, x, startY + spacing, buttonWidth, buttonHeight);
        addCharacterButton(JjkCharacter.YUJI_ITADORI, x, startY + spacing * 2, buttonWidth, buttonHeight);
    }

    private void addCharacterButton(
            JjkCharacter character,
            int x,
            int y,
            int width,
            int height
    ) {
        Component text = Component.translatable(character.translationKey())
                .append(Component.literal(" — " + character.baseCursedEnergy() + " CE"));

        Button button = Button.builder(
                        text,
                        ignored -> chooseCharacter(character)
                )
                .bounds(x, y, width, height)
                .build();

        addRenderableWidget(button);
    }

    private void chooseCharacter(JjkCharacter character) {
        if (requestInFlight) {
            return;
        }

        if (!ClientPlayNetworking.canSend(CharacterSelectPayload.TYPE)) {
            status = Component.translatable("screen.jjkmod.network_error");
            return;
        }

        requestInFlight = true;
        status = Component.translatable("screen.jjkmod.waiting");
        ClientPlayNetworking.send(new CharacterSelectPayload(character.id()));
    }

    public void serverRequiresSelection() {
        selectionConfirmed = false;
        requestInFlight = false;
        status = Component.translatable("screen.jjkmod.choose_character");
    }

    public void selectionConfirmed(CharacterStatePayload payload) {
        selectionConfirmed = true;
        requestInFlight = false;
        status = Component.translatable("screen.jjkmod.selected");

        if (this.minecraft != null) {
            this.minecraft.gui.setScreen(null);
        }
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return selectionConfirmed;
    }

    @Override
    public void onClose() {
        if (!selectionConfirmed) {
            return;
        }
        super.onClose();
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void extractRenderState(
            GuiGraphicsExtractor graphics,
            int mouseX,
            int mouseY,
            float delta
    ) {
        super.extractRenderState(graphics, mouseX, mouseY, delta);

        graphics.centeredText(
                this.font,
                this.title,
                this.width / 2,
                this.height / 2 - 90,
                0xFFFFFFFF
        );

        graphics.centeredText(
                this.font,
                status,
                this.width / 2,
                this.height / 2 + 45,
                0xFFBDBDBD
        );
    }
}
