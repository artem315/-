package dev.artyonix.jjk.client;

import dev.artyonix.jjk.client.gui.CharacterSelectScreen;
import dev.artyonix.jjk.network.CharacterStatePayload;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.Minecraft;

public final class JjkClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ClientPlayNetworking.registerGlobalReceiver(
                CharacterStatePayload.TYPE,
                (payload, context) -> {
                    Minecraft client = context.client();

                    if (payload.selectionRequired()) {
                        if (client.screen instanceof CharacterSelectScreen currentScreen) {
                            currentScreen.serverRequiresSelection();
                            return;
                        }

                        client.gui.setScreen(new CharacterSelectScreen());
                        return;
                    }

                    if (client.screen instanceof CharacterSelectScreen selectScreen) {
                        selectScreen.selectionConfirmed(payload);
                    }
                }
        );
    }
}
